# The Highcharts export server has moved
We decided to move the code for the export servers for Java, PhantomJS and PHP to its own repository [highcharts-export-server](https://github.com/highcharts/highcharts-export-server).
You'll find the repository here, https://github.com/highcharts/highcharts-export-server.

You will find documentation for getting started and setting up the server [here](http://www.highcharts.com/docs/export-module/export-module-overview)  

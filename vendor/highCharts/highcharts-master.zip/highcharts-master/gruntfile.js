/* global module */
module.exports = function (grunt) {
    'use strict';

    // load other tasks in current directory
    grunt.loadTasks('./grunt-tasks');
};

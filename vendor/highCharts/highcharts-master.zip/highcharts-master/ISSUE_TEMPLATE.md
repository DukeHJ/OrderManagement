#### Expected behaviour


#### Actual behaviour


#### Live demo with steps to reproduce
<!-- template: jsfiddle.net/highcharts/llexl/ -->


#### Affected browser(s)

